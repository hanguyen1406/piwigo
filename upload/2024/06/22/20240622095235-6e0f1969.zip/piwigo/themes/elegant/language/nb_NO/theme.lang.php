<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Velg hva som skal være standard tilstand på hvert panel, eller slå av animasjon';
$lang['Comments Panel'] = 'Kommentarpanel';
$lang['Disable the animation'] = 'Slå av animasjon';
$lang['Displayed'] = 'Sett';
$lang['Elegant, Configuration Page'] = 'Elegant, konfigurasjonspanel';
$lang['Hidden'] = 'Skult';
$lang['Main Menu Panel'] = 'Hovedmenypanel';
$lang['Panels options'] = 'Paneltilpassinger';
$lang['Photo Description Panel'] = 'Bildebeskrivelesespanel';
?>