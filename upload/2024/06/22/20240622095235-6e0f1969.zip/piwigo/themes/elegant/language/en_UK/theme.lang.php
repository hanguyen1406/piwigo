<?php
$lang['Elegant, Configuration Page'] = 'Elegant, Configuration Page';
$lang['Panels options'] = 'Panels options';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Choose what should be the default state for each panel, or disable the animation:';
$lang['Main Menu Panel'] = 'Main Menu Panel';
$lang['Displayed'] = 'Displayed';
$lang['Hidden'] = 'Hidden';
$lang['Disable the animation'] = 'Disable the animation';
$lang['Photo Description Panel'] = 'Photo Description Panel';
$lang['Comments Panel'] = 'Comments Panel';
?>