<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = '選擇每個面板的默認狀態，或停用動畫：';
$lang['Comments Panel'] = '留言面板';
$lang['Disable the animation'] = '停用動畫';
$lang['Displayed'] = '已顯示';
$lang['Elegant, Configuration Page'] = '優雅，設定頁面';
$lang['Hidden'] = '隱蔽';
$lang['Main Menu Panel'] = '主目錄面板';
$lang['Panels options'] = '面板選項';
$lang['Photo Description Panel'] = '相片描述面板';
?>