<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Photo Description Panel'] = 'Panel popisu fotky';
$lang['Panels options'] = 'Panlely možností';
$lang['Main Menu Panel'] = 'Panel ponuky';
$lang['Hidden'] = 'Skryté';
$lang['Elegant, Configuration Page'] = 'Elegantný, stránka konfigurácie';
$lang['Displayed'] = 'Zobrazené';
$lang['Disable the animation'] = 'Zakázať animáciu';
$lang['Comments Panel'] = 'Panel komentárov';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Vyberte si, čo by mal byť východiskový stav pre každý panel, alebo zakázať animáciu';
?>