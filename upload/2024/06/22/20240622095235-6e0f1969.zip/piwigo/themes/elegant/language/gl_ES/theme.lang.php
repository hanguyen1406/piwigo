<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Escoller cal debería ser o estado predeterminado para cada panel, ou desactivar a animación:';
$lang['Comments Panel'] = 'Panel comentarios';
$lang['Disable the animation'] = 'Desactivar animación';
$lang['Displayed'] = 'Amosado';
$lang['Elegant, Configuration Page'] = 'Elegante, páxina de configuración';
$lang['Hidden'] = 'Agochado';
$lang['Main Menu Panel'] = 'Panel do menú principal';
$lang['Panels options'] = 'Opcións dos paneis';
$lang['Photo Description Panel'] = 'Panel descrición de foto';