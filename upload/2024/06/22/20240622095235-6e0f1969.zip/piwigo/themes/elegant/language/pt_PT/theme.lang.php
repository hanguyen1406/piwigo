<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Escolha o que deverá ser definido para cada painel ou desative a animação.';
$lang['Comments Panel'] = 'Painel de comentários';
$lang['Disable the animation'] = 'Desativar a animação';
$lang['Displayed'] = 'Mostrado';
$lang['Elegant, Configuration Page'] = 'Eleganmte, página de configuração';
$lang['Hidden'] = 'Omitido';
$lang['Main Menu Panel'] = 'Painel do menú principal ';
$lang['Panels options'] = 'Opções dos paineis';
$lang['Photo Description Panel'] = 'Painel de descrição da foto';
?>