<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Comments Panel'] = 'Iruzkinen panela';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Aukeratu zein izan beharko litzatekeen panel bakoitzeko lehenetsitako egoera, edo animazioa ezgaitu:';
$lang['Disable the animation'] = 'Ezgaitu animazioa';
$lang['Elegant, Configuration Page'] = 'Elegant, konfigurazio orria';
$lang['Hidden'] = 'Ezkutatuta';
$lang['Main Menu Panel'] = 'Menu nagusiaren panela';
$lang['Displayed'] = 'Bistaratuta';
$lang['Panels options'] = 'Panelen aukerak';
$lang['Photo Description Panel'] = 'Argazkien deskribapenen panela';