<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Hidden'] = 'மறைந்துள்ள';
$lang['Main Menu Panel'] = 'முதன்மை மெனுவிலுள்ள குழு';
$lang['Panels options'] = 'பலகங்கள் விருப்பங்கள்';
$lang['Photo Description Panel'] = 'புகைப்பட விவரிப்பு பலகம்';
$lang['Elegant, Configuration Page'] = 'நளினமான, ​​கட்டமைப்பு பக்கம்';
$lang['Displayed'] = 'காண்பிக்கப்படும்';
$lang['Comments Panel'] = 'கருத்துரைகள் குழு';
$lang['Disable the animation'] = 'அனிமேசன் செயலிழக்க';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'தேர்வு செய்யவும் முன்னிருப்பு என்னவாக இருக்க வேண்டும்
ஒவ்வொரு குழு நிலை,  அல்லது அனிமேஷன் செயலிழக்க:';
?>