<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Izberite privzeto stanje za vsak panel ali pa onemogočite animacijo';
$lang['Comments Panel'] = 'Panel komentarjev';
$lang['Disable the animation'] = 'Onemogoči animacijo';
$lang['Displayed'] = 'Prikazano';
$lang['Elegant, Configuration Page'] = 'Elegantno, Nastavitveni panel';
$lang['Hidden'] = 'Skrito';
$lang['Main Menu Panel'] = 'Panel glavnega menija';
$lang['Panels options'] = 'Možnosti panela';
$lang['Photo Description Panel'] = 'Panel opisal fotografij';
?>