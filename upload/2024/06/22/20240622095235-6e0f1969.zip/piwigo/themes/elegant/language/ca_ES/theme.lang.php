<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Escolliu l\'estat per defecte de cada panell, o deshabiliteu l\'animació:';
$lang['Comments Panel'] = 'Panell de comentaris';
$lang['Disable the animation'] = 'Deshabilitar l\'animació';
$lang['Displayed'] = 'Visualitzat';
$lang['Elegant, Configuration Page'] = 'Elegant, Pàgina de configuració';
$lang['Hidden'] = 'Amagat';
$lang['Main Menu Panel'] = 'Panell del menú principal';
$lang['Panels options'] = 'Opcions dels panells';
$lang['Photo Description Panel'] = 'Panell de descripció de la foto';
?>