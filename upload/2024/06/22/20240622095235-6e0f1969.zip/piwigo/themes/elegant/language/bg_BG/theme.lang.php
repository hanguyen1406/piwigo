<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Изберете какъв ще бъде по подразбиране всеки панел или забранете анимирането:';
$lang['Photo Description Panel'] = 'Панел с описание на снимки';
$lang['Panels options'] = 'Панел опции';
$lang['Main Menu Panel'] = 'Панел на основното меню';
$lang['Hidden'] = 'Скрито';
$lang['Elegant, Configuration Page'] = 'Elegant, конфигурационна страница';
$lang['Disable the animation'] = 'Забрана на анимация';
$lang['Displayed'] = 'Показани';
$lang['Comments Panel'] = 'Панел с коментари';
?>