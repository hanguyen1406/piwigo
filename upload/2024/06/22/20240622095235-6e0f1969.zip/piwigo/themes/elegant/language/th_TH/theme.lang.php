<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = '
เลือกสิ่งที่ควรมีในตอนเริ่มต้นสำหรับแต่ละแผงหรือปิดการใช้งานภาพเคลื่อนไหว :';
$lang['Comments Panel'] = 'แผงความเห็น';
$lang['Disable the animation'] = 'ปิดการใช้งานภาพเคลื่อนไหว';
$lang['Displayed'] = 'การแสดงผล';
$lang['Elegant, Configuration Page'] = 'สง่างามหน้าการกำหนดค่า';
$lang['Hidden'] = 'ซ่อน';
$lang['Main Menu Panel'] = 'แผงเมนูหลัก';
$lang['Panels options'] = 'ตัวเลือกแผง';
$lang['Photo Description Panel'] = 'แผงรายละเอียดรูปภาพ';
?>