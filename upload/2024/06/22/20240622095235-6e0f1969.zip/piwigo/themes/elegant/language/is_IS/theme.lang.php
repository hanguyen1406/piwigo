<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Veldu hvað ætti að vera sjálfgefið ástand fyrir hvern borða, eða slökktu á hreyfimyndinni:';
$lang['Comments Panel'] = 'Umsagnaborði';
$lang['Disable the animation'] = 'Afvirkja hreyfimyndina';
$lang['Displayed'] = 'Sýnd';
$lang['Elegant, Configuration Page'] = 'Glæsileg, stillingarsíða';
$lang['Hidden'] = 'Falin';
$lang['Main Menu Panel'] = 'Aðalvalmyndaborði';
$lang['Panels options'] = 'Borðamöguleikar';
$lang['Photo Description Panel'] = 'Myndlýsingaborði';