<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Geef de standaardtoestand van elk paneel, of schakel de animatie uit:';
$lang['Comments Panel'] = 'Commentaar-paneel';
$lang['Disable the animation'] = 'Schakel de animatie uit';
$lang['Displayed'] = 'Weergegeven';
$lang['Elegant, Configuration Page'] = 'Elegant, Configuratiepagina';
$lang['Main Menu Panel'] = 'Hoofdmenu-paneel';
$lang['Panels options'] = 'Paneel-opties';
$lang['Photo Description Panel'] = 'Afbeeldingenbeschrijvings-paneel';
$lang['Hidden'] = 'Verborgen';
?>