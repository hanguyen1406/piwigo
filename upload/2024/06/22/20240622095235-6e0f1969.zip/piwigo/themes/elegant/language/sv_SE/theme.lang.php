<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Photo Description Panel'] = 'Fotobeskrivnings-panel';
$lang['Main Menu Panel'] = 'Huvudmeny-panel';
$lang['Elegant, Configuration Page'] = 'Elegant, konfigurationssida';
$lang['Hidden'] = 'Dölj';
$lang['Displayed'] = 'Visa';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Välj standardtillståndet för varje panel, eller inaktivera animationen:';
$lang['Disable the animation'] = 'Inaktivera animationen';
$lang['Panels options'] = 'Panelinställningar';
$lang['Comments Panel'] = 'Kommentarspanel';
?>