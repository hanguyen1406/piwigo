<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Állítsa be milyen legyen a panel alapértelmezett állapotban, vagy tiltsa le az animációt:';
$lang['Panels options'] = 'Panelek lehetőségei';
$lang['Comments Panel'] = 'Hozzászólások panel';
$lang['Disable the animation'] = 'Animáció kikapcsolása';
$lang['Displayed'] = 'Megjelenítés';
$lang['Elegant, Configuration Page'] = 'Elegant, beállítás oldal';
$lang['Hidden'] = 'Rejtett';
$lang['Main Menu Panel'] = 'Főmenü panel';
$lang['Photo Description Panel'] = 'Kép leírás panel';
?>