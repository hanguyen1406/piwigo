<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Elegant, Configuration Page'] = 'Elegant, Yapılandırma Sayfası';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Her panel için varsayılanın ne olması gerektiğini seçin veya animasyonu devre dışı bırakın:';
$lang['Comments Panel'] = 'Yorumlar Paneli';
$lang['Photo Description Panel'] = 'Fotoğraf Açıklama Paneli';
$lang['Panels options'] = 'Panel seçenekleri';
$lang['Main Menu Panel'] = 'Ana Menü Paneli';
$lang['Hidden'] = 'Gizli';
$lang['Displayed'] = 'Görüntülendi';
$lang['Disable the animation'] = 'Animasyonu devre dışı bırak';
?>