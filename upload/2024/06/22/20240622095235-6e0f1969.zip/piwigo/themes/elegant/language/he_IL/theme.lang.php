<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Panels options'] = 'אפשרויות לוחות';
$lang['Elegant, Configuration Page'] = 'דף תצורה, מהודר';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'בחר את ברירת המחדל עבור כל לוח, או בטל את ההנפשה:';
$lang['Disable the animation'] = 'בטל את ההנפשות';
$lang['Comments Panel'] = 'לוח תגובות';
$lang['Main Menu Panel'] = 'לוח תפריט ראשי';
$lang['Photo Description Panel'] = 'לוח תיאור תמונה';
$lang['Displayed'] = 'מוצג';
$lang['Hidden'] = 'מוסתר';