<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Comments Panel'] = 'コメント一覧';
$lang['Disable the animation'] = 'アニメーションを使用しない';
$lang['Photo Description Panel'] = '詳細';
$lang['Panels options'] = 'オプション';
$lang['Main Menu Panel'] = 'メインメニュー';
$lang['Hidden'] = '隠す';
$lang['Displayed'] = '表示する';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = '各パネルのデフォルトでの状態、アニメーションの無効化などを選択して下さい';
$lang['Elegant, Configuration Page'] = 'Elagant設定ページ';