<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Escolha qual deve ser o estado padrão para cada painel, ou desativar a animação:';
$lang['Comments Panel'] = 'Painel de Comentários';
$lang['Disable the animation'] = 'Desabilitar a animação';
$lang['Displayed'] = 'Exibido';
$lang['Elegant, Configuration Page'] = 'Elegante, Página de Configuração';
$lang['Hidden'] = 'Oculto';
$lang['Main Menu Panel'] = 'Painel do Menu Principal';
$lang['Panels options'] = 'Opções de painéis';
$lang['Photo Description Panel'] = 'Painel de Descrição de Foto';
?>