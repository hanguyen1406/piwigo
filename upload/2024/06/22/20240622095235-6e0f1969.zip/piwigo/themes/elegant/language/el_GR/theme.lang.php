<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Photo Description Panel'] = 'Πάνελ Περιγραφής Φωτογραφίας ';
$lang['Panels options'] = 'επιλογές πάνελ';
$lang['Main Menu Panel'] = 'Πάνελ Κύριου μενού';
$lang['Hidden'] = 'Κρυφό';
$lang['Elegant, Configuration Page'] = 'Elegant, διαμόρφωσης σελίδας';
$lang['Displayed'] = 'Εμφανιζόμενο';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Επιλέξτε αυτό που θα θέλατε να είναι η προεπιλεγμένη κατάσταση για κάθε πάνελ, ή απενεργοποιήσετε τα κινούμενα σχέδια:';
$lang['Disable the animation'] = 'Απενεργοποιήστε τα κινούμενα σχέδια';
$lang['Comments Panel'] = 'Πάνελ Σχολίων';
?>