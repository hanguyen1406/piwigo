<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Elegant, Configuration Page'] = 'Сторінка конфігурації теми Елегантний';
$lang['Panels options'] = 'Панелі параметрів';
$lang['Photo Description Panel'] = 'Панель опису зображень';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Виберіть те, що має стан за замовчуванням для кожної панелі, або відключити анімацію:';
$lang['Comments Panel'] = 'Панель коментарів';
$lang['Disable the animation'] = 'Вимкнути анімацію';
$lang['Displayed'] = 'Показано';
$lang['Hidden'] = 'Приховано';
$lang['Main Menu Panel'] = 'Головне меню панелі';
?>