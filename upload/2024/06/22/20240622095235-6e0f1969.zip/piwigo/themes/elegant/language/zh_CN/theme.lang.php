<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = '选择每个面板的默认状态，或禁用动画：';
$lang['Disable the animation'] = '禁用动画';
$lang['Displayed'] = '显示的';
$lang['Elegant, Configuration Page'] = 'Elegant，设置页';
$lang['Hidden'] = '隐藏的';
$lang['Comments Panel'] = '评论面板';
$lang['Main Menu Panel'] = '主菜单面板';
$lang['Panels options'] = '面板选项';
$lang['Photo Description Panel'] = '图片描述面板';
?>