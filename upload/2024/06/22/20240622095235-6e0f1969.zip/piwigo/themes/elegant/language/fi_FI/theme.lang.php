<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Valitse kunkin paneelin oletustila, tai poista animaatio käytöstä:';
$lang['Comments Panel'] = 'Kommenttipaneeli';
$lang['Disable the animation'] = 'Poista animaatio käytöstä';
$lang['Displayed'] = 'Näkyvissä';
$lang['Elegant, Configuration Page'] = 'Aistikas, asetussivu';
$lang['Hidden'] = 'Piilotettu';
$lang['Main Menu Panel'] = 'Päävalikkopaneeli';
$lang['Panels options'] = 'Paneelien asetukset';
$lang['Photo Description Panel'] = 'Kuvan tiedot -paneeli';
?>