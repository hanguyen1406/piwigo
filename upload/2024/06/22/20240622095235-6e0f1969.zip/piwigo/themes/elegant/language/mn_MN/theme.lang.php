<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Elegant, Configuration Page'] = 'Тохиргооны хуудас';
$lang['Comments Panel'] = 'Сэтгэгдэлийн талбар';
$lang['Disable the animation'] = 'Анимейшнийг хаах ';
$lang['Hidden'] = 'Нуугдмал';
$lang['Displayed'] = 'Харуулах';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Хэсэг тус бүрийн тохиргоог сонгох буюу анимейшнийг хаах:';
$lang['Main Menu Panel'] = 'Үндсэн цэсийн хэсэг';
$lang['Panels options'] = 'Талбарын тохиргоо';
$lang['Photo Description Panel'] = 'Зургын тайлбар хэсэг';
?>