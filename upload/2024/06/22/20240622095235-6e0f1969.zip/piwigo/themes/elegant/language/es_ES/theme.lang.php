<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Elija lo que debería ser el estado por defecto para cada panel o desactivar la animación:';
$lang['Comments Panel'] = 'Panel de comentarios ';
$lang['Disable the animation'] = 'Desactivar la animación';
$lang['Displayed'] = 'Mostrado';
$lang['Elegant, Configuration Page'] = 'Pagina de configuración de Elegant';
$lang['Hidden'] = 'Esconder';
$lang['Main Menu Panel'] = 'Panel del menú principal';
$lang['Panels options'] = 'Opciones del panel';
$lang['Photo Description Panel'] = 'Descripción de la foto del panel';
?>