<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Выберите, что должно быть по умолчанию для каждой группы, или отключите анимацию:  ';
$lang['Comments Panel'] = 'Панель комментариев';
$lang['Disable the animation'] = 'Отключить анимацию';
$lang['Displayed'] = 'Отображено';
$lang['Elegant, Configuration Page'] = 'Страница настройки темы Elegant';
$lang['Hidden'] = 'Скрыто';
$lang['Main Menu Panel'] = 'Панель главного меню';
$lang['Panels options'] = 'Панели функций';
$lang['Photo Description Panel'] = 'Панель описания изображений';
?>