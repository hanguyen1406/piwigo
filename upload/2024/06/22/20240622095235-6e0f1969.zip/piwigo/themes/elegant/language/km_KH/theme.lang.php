<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'ជ្រើសអ្វីដែលគួរតែត្រូវបាន​ស្ថិតនៅជា​លំនាំដើម សម្រាប់បន្ទះនិមួយៗ ឬបិទចលនាតែម្តង៖';
$lang['Comments Panel'] = 'បន្ទះមតិ';
$lang['Disable the animation'] = 'បិទចលនា';
$lang['Displayed'] = 'បានបង្ហាញ';
$lang['Elegant, Configuration Page'] = 'Elegant, ទំព័រកំណត់រចនា';
$lang['Hidden'] = 'លាក់';
$lang['Main Menu Panel'] = 'បន្ទះម៉ឺនុយមេ';
$lang['Panels options'] = 'បន្ទះជម្រើស';
$lang['Photo Description Panel'] = 'បន្ទះពណ៌នា​រូបភាព';
?>