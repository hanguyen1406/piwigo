<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'اختيار ما ينبغي أن تكون علية الحالة الافتراضية لكل لوحة، أو تعطيل الرسوم المتحركة:';
$lang['Comments Panel'] = 'لوحة التعليقات';
$lang['Disable the animation'] = 'تعطيل الرسوم المتحركة';
$lang['Displayed'] = 'عرض';
$lang['Elegant, Configuration Page'] = 'الأنيق، صفحة التكوين';
$lang['Hidden'] = 'مخفي';
$lang['Main Menu Panel'] = 'لوحة القائمة الرئيسية ';
$lang['Panels options'] = 'خيارات اللوحات';
$lang['Photo Description Panel'] = 'لوحة وصف الصورة';
?>