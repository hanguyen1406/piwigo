<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Standard-Status für jedes Panel festlegen oder Animation deaktivieren';
$lang['Comments Panel'] = 'Kommentarübersicht';
$lang['Disable the animation'] = 'Animation deaktivieren';
$lang['Displayed'] = 'Angezeigt';
$lang['Elegant, Configuration Page'] = 'Elegant, Konfigurationsseite';
$lang['Hidden'] = 'Ausgeblendet';
$lang['Main Menu Panel'] = 'Hauptmenü';
$lang['Panels options'] = 'Optionen';
$lang['Photo Description Panel'] = 'Fotobeschreibungen';