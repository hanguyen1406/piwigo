<?php

$lang['Elegant, Configuration Page'] = 'Élégant, Page de Configuration';
$lang['Panels options'] = 'Options des panneaux';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Choisissez le comportement par défaut des panneaux rétractables, ou désactivez leur animation';
$lang['Main Menu Panel'] = 'Panneau du menu principal';
$lang['Displayed'] = 'Affiché';
$lang['Hidden'] = 'Caché';
$lang['Disable the animation'] = 'Désactiver l\'animation';
$lang['Photo Description Panel'] = 'Panneau de description de la photo';
$lang['Comments Panel'] = 'Panneau des commentaires'; 
?>