<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Vali igale paneelile vaikimis olek või lülita animatsioon välja:';
$lang['Comments Panel'] = 'Kommentaaride paneel';
$lang['Disable the animation'] = 'Lülita animatsioon välja';
$lang['Displayed'] = 'Näidatakse';
$lang['Elegant, Configuration Page'] = 'Elegant, seadistuspaneel';
$lang['Hidden'] = 'Peidetud';
$lang['Main Menu Panel'] = 'Peamenüü paneel';
$lang['Panels options'] = 'Paneeli seaded';
$lang['Photo Description Panel'] = 'Pildi kirjelduste paneel';