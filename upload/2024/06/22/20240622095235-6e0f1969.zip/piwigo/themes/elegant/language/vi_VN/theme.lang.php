<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Chọn trạng thái mặc định cho mỗi bảng, hoặc vô hiệu hóa tính năng hoạt hình';
$lang['Comments Panel'] = 'Bảng bình luận';
$lang['Disable the animation'] = 'Vô hiệu hóa tính năng hoạt hình';
$lang['Displayed'] = 'Được hiển thị';
$lang['Elegant, Configuration Page'] = 'Elegant, Trang cấu hình';
$lang['Hidden'] = 'Ẩn';
$lang['Main Menu Panel'] = 'Bảng Menu chính';
$lang['Panels options'] = 'Tùy chọn bảng';
$lang['Photo Description Panel'] = 'Bảng mô tả ảnh';
?>