<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Elegant, Configuration Page'] = 'Elegant konfigūracijos puslapis';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Pasirinkite kokia turėtų būti kiekvieno skydelio būsena arba išjunkite animaciją';
$lang['Comments Panel'] = 'Komentarų skydelis';
$lang['Disable the animation'] = 'Išjungti animaciją';
$lang['Displayed'] = 'Rodoma';
$lang['Hidden'] = 'Paslėpta';
$lang['Main Menu Panel'] = 'Pagrindinio meniu skydelis';
$lang['Panels options'] = 'Skydelių parinktys';
$lang['Photo Description Panel'] = 'Foto aprašymo skydelis';
?>