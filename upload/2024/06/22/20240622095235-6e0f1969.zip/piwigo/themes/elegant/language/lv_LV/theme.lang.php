<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Main Menu Panel'] = 'Galvenās Izvēlnes Panelis';
$lang['Hidden'] = 'Paslēpts';
$lang['Disable the animation'] = 'atslēgt animāciju';
$lang['Comments Panel'] = 'Komentāru panelis';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Izvēlēties, kas būtu katra paneļa noklusējuma stāvoklis vai atspējot animācijas:';
$lang['Elegant, Configuration Page'] = 'Elegants, Konfigurācijas Lapa';
$lang['Displayed'] = 'Attēlots';
$lang['Photo Description Panel'] = 'Fotogrāfiju Apraksta Panelis';
$lang['Panels options'] = 'Paneļa opcijas';
?>