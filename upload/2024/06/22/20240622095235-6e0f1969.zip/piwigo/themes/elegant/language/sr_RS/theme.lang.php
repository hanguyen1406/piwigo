<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Изаберите подразумеван приказ сваке површи или искључите анимацију:';
$lang['Comments Panel'] = 'Површ за коментаре';
$lang['Disable the animation'] = 'Онемогући анимацију';
$lang['Displayed'] = 'Приказано';
$lang['Elegant, Configuration Page'] = 'Подешавања Елегантне теме';
$lang['Hidden'] = 'Сакривено';
$lang['Main Menu Panel'] = 'Површ са главним менијем';
$lang['Panels options'] = 'Опције панела';
$lang['Photo Description Panel'] = 'Површ са описом фотографије';