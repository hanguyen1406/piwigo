<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Hvad hvad der skal være hvert panels standardtilstand, eller deaktiver animationen:';
$lang['Comments Panel'] = 'Kommentarpanel';
$lang['Disable the animation'] = 'Deaktiver animationen';
$lang['Displayed'] = 'Vist';
$lang['Elegant, Configuration Page'] = 'Elegant, Opsætningspanel';
$lang['Hidden'] = 'Skjult';
$lang['Main Menu Panel'] = 'Panelets hovedmenu';
$lang['Panels options'] = 'Panelindstillinger';
$lang['Photo Description Panel'] = 'Fotobeskrivelsespanel';
?>