<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Photo Description Panel'] = 'Fotopriskriba panelo';
$lang['Panels options'] = 'Panelaj opcioj';
$lang['Main Menu Panel'] = 'Panelo de la ĉefa menuo';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Elektu, kion estu la apriora stato de ĉiu panelo, aŭ malŝaltu la animacio:';
$lang['Elegant, Configuration Page'] = 'Agordopaĝo de Elegant';
$lang['Comments Panel'] = 'Panelo por komentoj';
$lang['Disable the animation'] = 'Malŝalti la animacion';
$lang['Displayed'] = 'Montrita';
$lang['Hidden'] = 'Kaŝita';
?>