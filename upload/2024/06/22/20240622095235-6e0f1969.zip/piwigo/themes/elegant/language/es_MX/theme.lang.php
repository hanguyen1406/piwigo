<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Elegant, Configuration Page'] = 'Página de configuración elegante';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Elija cuál debería ser el estado predeterminado para cada panel, o deshabilite la animación:';
$lang['Comments Panel'] = 'Panel de comentarios';
$lang['Disable the animation'] = 'Deshabilitar la animación';
$lang['Displayed'] = 'Desplegado';
$lang['Hidden'] = 'Oculto';
$lang['Main Menu Panel'] = 'Panel del menú principal';
$lang['Panels options'] = 'Opciones de paneles';
$lang['Photo Description Panel'] = 'Foto Descripción Panel';