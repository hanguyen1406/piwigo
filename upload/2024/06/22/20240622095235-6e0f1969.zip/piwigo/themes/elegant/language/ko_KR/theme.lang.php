<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = '각 패널의 기본 상태와 애니메이션을 비활성화 할 지 선택하십시오.';
$lang['Comments Panel'] = '댓글 패널';
$lang['Disable the animation'] = '애니메이션 비활성화';
$lang['Displayed'] = '보임';
$lang['Elegant, Configuration Page'] = 'Elegant, 설정 페이지';
$lang['Hidden'] = '숨김';
$lang['Main Menu Panel'] = '메인 메뉴 패널';
$lang['Panels options'] = '패널 옵션';
$lang['Photo Description Panel'] = '사진 설명 패널';
?>