<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Wybierz domyślny stan dla każdego panelu lub wyłącz animację:';
$lang['Comments Panel'] = 'Panel komentarzy';
$lang['Disable the animation'] = 'Wyłącz animację';
$lang['Displayed'] = 'Wyświetlane';
$lang['Elegant, Configuration Page'] = 'Strona konfiguracyjna Elegant';
$lang['Hidden'] = 'Ukryte';
$lang['Main Menu Panel'] = 'Panel głównego menu';
$lang['Panels options'] = 'Opcje panelu';
$lang['Photo Description Panel'] = 'Panel opisu zdjęć';
?>