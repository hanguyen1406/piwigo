<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Elegant, Configuration Page'] = 'ಎಲಿಗ್ಯಾಂಟ್, ಕಾನ್ಫಿಗರೇಶನ್ ಪುಟ';
$lang['Hidden'] = 'ಬಚ್ಚಿಟ್ಟದ್ದು';
$lang['Main Menu Panel'] = 'ಮುಖ್ಯ ಆಯ್ಕೆಪಟ್ಟಿ ಪ್ಯಾನೆಲ್';
$lang['Panels options'] = 'ಪ್ಯಾನೆಲ್ ಗಳ ಆಯ್ಕೆಗಳು';
$lang['Photo Description Panel'] = 'ಚಿತ್ರದ ವಿವರಣೆ ಪ್ಯಾನೆಲ್';
$lang['Displayed'] = 'ಪ್ರದರ್ಶಿಸಲಾಗಿದೆ';
$lang['Disable the animation'] = 'ಅನಿಮೇಶನ್ ಅನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ';
$lang['Comments Panel'] = 'ಟಿಪ್ಪಣಿಗಳ ಪ್ಯಾನೆಲ್';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'ಪ್ರತಿಯೊಂದು ಪ್ಯಾನೆಲ್ ನ ಪೂರ್ವನಿಯೋಜಿತ ಸ್ಥಿತಿ ಏನಿರಬೇಕೆಂದು ಆರಿಸಿ, ಅಥವಾ ಅನಿಮೇಶನ್ ಅನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ.';
?>