<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Comments Panel'] = 'Panel for kommentarar';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Vel kva som skal vera standard for kvart panel, eller ikkje vis animering:';
$lang['Disable the animation'] = 'Ikkje vis animasjonar';
$lang['Elegant, Configuration Page'] = 'Elegant - innstillingsside';
$lang['Main Menu Panel'] = 'Panel for hovudmeny';
$lang['Panels options'] = 'Panelinnstillingar';
$lang['Photo Description Panel'] = 'Panel for biletskildring';
$lang['Displayed'] = 'Vist';
$lang['Hidden'] = 'Gøymd';
?>