<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Alege care ar trebui să fie starea implicită pentru fiecare panou, sau dezactivează animația.';
$lang['Comments Panel'] = 'Panou de comentarii';
$lang['Disable the animation'] = 'Dezactivează animația';
$lang['Displayed'] = 'Afișat';
$lang['Elegant, Configuration Page'] = 'Pagină de configurare pentru Elegant';
$lang['Hidden'] = 'Ascuns';
$lang['Main Menu Panel'] = 'Panou meniu principal';
$lang['Panels options'] = 'Panou de optiuni';
$lang['Photo Description Panel'] = 'Panou de descrierea fotografiei';
?>