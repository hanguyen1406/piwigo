<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Photo Description Panel'] = 'Pannello Descrizione Foto';
$lang['Panels options'] = 'Pannelli opzioni';
$lang['Main Menu Panel'] = 'Pannello Menu Principale';
$lang['Hidden'] = 'Nascosto';
$lang['Elegant, Configuration Page'] = 'Elegante, Pagina di configurazione';
$lang['Displayed'] = 'Visualizza';
$lang['Disable the animation'] = 'Disabilita l\'animazione';
$lang['Comments Panel'] = 'Pannello Commenti';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Scegli quello che dovrebbe essere lo stato predefinito per ogni pannello, o disattiva l\'animazione:';
?>