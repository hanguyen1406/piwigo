<?php
$lang['Elegant, Configuration Page'] = 'Elegant, stránka s konfigurací';
$lang['Panels options'] = 'Nastavení panelů';
$lang['Choose what should be the default state for each panel, or disable the animation:'] = 'Nastavte výchozí stav pro každý panel nebo deaktivujte animaci:';
$lang['Main Menu Panel'] = 'Hlavní menu panel';
$lang['Displayed'] = 'Zobrazen';
$lang['Hidden'] = 'Skryt';
$lang['Disable the animation'] = 'Deaktivovat animaci';
$lang['Photo Description Panel'] = 'Panel s popisem fotografií';
$lang['Comments Panel'] = 'Panel komentářů';
?>