<?php
// +-----------------------------------------------------------------------+
// | Piwigo - a PHP based photo gallery                                    |
// +-----------------------------------------------------------------------+
// | Copyright(C) 2008-2013 Piwigo Team                  http://piwigo.org |
// | Copyright(C) 2003-2008 PhpWebGallery Team    http://phpwebgallery.net |
// | Copyright(C) 2002-2003 Pierrick LE GALL   http://le-gall.net/pierrick |
// +-----------------------------------------------------------------------+
// | This program is free software; you can redistribute it and/or modify  |
// | it under the terms of the GNU General Public License as published by  |
// | the Free Software Foundation                                          |
// |                                                                       |
// | This program is distributed in the hope that it will be useful, but   |
// | WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      |
// | General Public License for more details.                              |
// |                                                                       |
// | You should have received a copy of the GNU General Public License     |
// | along with this program; if not, write to the Free Software           |
// | Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, |
// | USA.                                                                  |
// +-----------------------------------------------------------------------+
$lang['%d album'] = '%d rummad';
$lang['%d albums'] = '%d rummad';
$lang['Explore'] = 'Furchal';
$lang['modus_theme'] = 'tem_modus';
$lang['Skin'] = 'Tem';
$lang['%d pixels'] = '%d piksel';
$lang['Album thumbnails'] = 'Skeudennoùigoù ar rummad';
$lang['Default size for thumbnails'] = 'Ment dre ziouer evit ar skeudennoùigoù';
$lang['Default size for thumbnails on high density display (retina)'] = 'Ment dre ziouer evit ar skeudennoùigoù gant skrammoù uhel o diarunusted (retina)';
$lang['Default sizes'] = 'Mentoù dre ziouer';
$lang['Modus theme config'] = 'Kefluniadur tem modus';
$lang['Use square thumbs'] = 'Ober gant skeudennigoù karrez';
$lang['Display page banner'] = 'Diskouez giton ar bajenn';