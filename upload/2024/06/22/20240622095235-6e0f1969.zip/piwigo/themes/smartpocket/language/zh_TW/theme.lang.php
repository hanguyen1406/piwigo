<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = '自動隱藏幻燈片列';
$lang['Loop the slideshow'] = '循環播放幻燈片';
$lang['More Information'] = '更多信息';
$lang['Slideshow Options'] = '幻燈片選項';
$lang['Smartpocket, Configuration Page'] = '智慧裝置的設置頁';