<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Auto ocultar a barra do show de slides';
$lang['Loop the slideshow'] = 'Passe o show de slides';
$lang['More Information'] = 'Mais Informações';
$lang['Slideshow Options'] = 'Opções do show de slide';
$lang['Smartpocket, Configuration Page'] = 'Bolso inteligente, Página de configuração';
?>