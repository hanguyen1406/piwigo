<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Автоматично приховувати панель слайд-шоу';
$lang['Loop the slideshow'] = 'Циклічне повторення слайд-шоу';
$lang['More Information'] = 'Додаткова інформація';
$lang['Slideshow Options'] = 'Параметри показу слайдів';
$lang['Smartpocket, Configuration Page'] = 'Сторінка налаштування Smartpocket';
?>