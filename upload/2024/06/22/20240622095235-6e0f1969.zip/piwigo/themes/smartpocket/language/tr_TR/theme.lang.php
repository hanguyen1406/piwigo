<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Slayt gösterisi çubuğunu otomatik gizle';
$lang['Loop the slideshow'] = 'Slayt gösterisini sürekli döndür';
$lang['More Information'] = 'Daha fazla bilgi';
$lang['Slideshow Options'] = 'Slayt gösterisi Seçenekleri';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Yapılandırma Sayfası';
?>