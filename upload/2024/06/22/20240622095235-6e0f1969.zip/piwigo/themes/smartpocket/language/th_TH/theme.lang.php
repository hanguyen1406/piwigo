<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'ซ่อนแถบสไลด์โชว์โดยอัตโนมัติ';
$lang['Loop the slideshow'] = 'วนสไลด์โชว์';
$lang['More Information'] = 'ข้อมูลเพิ่มเติม';
$lang['Slideshow Options'] = 'ตัวเลือกสไลด์โชว์';
$lang['Smartpocket, Configuration Page'] = 'หน้าการกำหนดค่าของ Smartpocket';