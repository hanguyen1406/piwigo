<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Автоматически скрывать панель слайд-шоу';
$lang['Loop the slideshow'] = 'Цикличное повторение слайд-шоу';
$lang['More Information'] = 'Дополнительная информация';
$lang['Slideshow Options'] = 'Функции слайд-щоу';
$lang['Smartpocket, Configuration Page'] = 'Страница конфигурации Smartpocket';
?>