<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = '自动隐藏幻灯栏';
$lang['Loop the slideshow'] = '幻灯循环播放';
$lang['Slideshow Options'] = '幻灯选项';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket，设置页';
$lang['More Information'] = '更多信息';
?>