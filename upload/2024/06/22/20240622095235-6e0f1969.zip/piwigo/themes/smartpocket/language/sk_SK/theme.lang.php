<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Automatické skrývanie panela prezentácie';
$lang['Loop the slideshow'] = 'Opakovať prezentácie';
$lang['Slideshow Options'] = 'Možnosti prezentácie';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, stránka konfigurácie';
$lang['More Information'] = 'Viac informácií';
?>