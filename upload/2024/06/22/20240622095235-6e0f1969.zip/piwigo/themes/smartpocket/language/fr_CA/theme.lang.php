<?php
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Page de configuration';
$lang['Slideshow Options'] = 'Options du diaporama';
$lang['Loop the slideshow'] = 'Boucler le diaporama';
$lang['Autohide the bar of the slideshow'] = 'Cacher automatiquement la barre du diaporama';
$lang['More Information'] = 'Plus d\'informations';
?>