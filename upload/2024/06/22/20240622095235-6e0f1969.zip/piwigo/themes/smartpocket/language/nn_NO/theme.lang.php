<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Gøym verktøylina for biletvising automatisk';
$lang['Loop the slideshow'] = 'Vis bilete ommatt';
$lang['Slideshow Options'] = 'Innstillingar for biletvising';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket - konfigureringsside';
$lang['More Information'] = 'Meir informasjon';
?>