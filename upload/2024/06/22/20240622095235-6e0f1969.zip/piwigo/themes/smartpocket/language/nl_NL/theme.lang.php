<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Loop the slideshow'] = 'Continu herhalen diashow';
$lang['Slideshow Options'] = 'Diashow-opties';
$lang['Autohide the bar of the slideshow'] = 'Verberg automatisch de diashow-balk';
$lang['More Information'] = 'Meer informatie';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, instellingenpagina';
?>