<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Nascondi automaticamente barra slideshow';
$lang['Loop the slideshow'] = 'Ciclica lo slideshow';
$lang['Slideshow Options'] = 'Opzioni slideshow';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Pagina Configurazione';
$lang['More Information'] = 'Ulteriori informazioni';
?>