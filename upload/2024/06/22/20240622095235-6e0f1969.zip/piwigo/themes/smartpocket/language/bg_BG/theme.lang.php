<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Loop the slideshow'] = 'Рамка на слайдшоу';
$lang['Autohide the bar of the slideshow'] = 'Автаматично скрива меню в слайдшоу';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Страница с настройки';
$lang['Slideshow Options'] = 'Опции за слайдшоу';
$lang['More Information'] = 'Повече информация';
?>