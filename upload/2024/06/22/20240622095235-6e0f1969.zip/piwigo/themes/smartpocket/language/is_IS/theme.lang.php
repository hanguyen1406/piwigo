<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Fela sjálfkrafa stikuna á skyggnusýningunni';
$lang['Loop the slideshow'] = 'Settu skyggnusýninguna í lykkju';
$lang['More Information'] = 'Frekari upplýsingar';
$lang['Slideshow Options'] = 'Valmöguleikar skyggnusýningar';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, uppsetningarsíða';