<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Ukrywaj belkę pokazu slajdów';
$lang['Loop the slideshow'] = 'Zapętl pokaz slajdów';
$lang['More Information'] = 'Więcej informacji';
$lang['Slideshow Options'] = 'Opcje pokazu slajdów';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, strona konfiguracyjna';