<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Аутоматски сакри траку аутоматског приказа';
$lang['Loop the slideshow'] = 'Покрећи аутоматски приказ изнова';
$lang['More Information'] = 'Више информација';
$lang['Slideshow Options'] = 'Опције аутоматског приказа';
$lang['Smartpocket, Configuration Page'] = 'Смарт покет, страница подешавања';