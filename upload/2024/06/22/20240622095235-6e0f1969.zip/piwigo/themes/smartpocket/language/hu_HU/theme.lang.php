<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Sáv automatikus elrejtése diavetítéskor';
$lang['Loop the slideshow'] = 'Diavetítés körbe';
$lang['More Information'] = 'További információ';
$lang['Slideshow Options'] = 'Diavetítés beállítások';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket beállítás oldal';