<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Слайдшоу-ний цэсийг автоматаар нуух';
$lang['Loop the slideshow'] = 'Слайдшоуг давтах';
$lang['More Information'] = 'Дэлгэрэнгүй';
$lang['Slideshow Options'] = 'Слайдшоу-ний тохиргоо';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket Тохиргооны хуудас';
?>