<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Diashow-Menüleiste automatisch ausblenden';
$lang['Loop the slideshow'] = 'Diashow in Endlosschleife';
$lang['More Information'] = 'Mehr Informationen';
$lang['Slideshow Options'] = 'Diashow-Optionen';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket-Konfigurationsseite';