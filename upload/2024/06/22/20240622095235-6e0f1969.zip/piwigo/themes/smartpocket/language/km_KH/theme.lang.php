<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Smartpocket, Configuration Page'] = 'Smartpocket ទំព័រ​រៀបចំរចនា';
$lang['Slideshow Options'] = 'ព័ត៌មាន​ជម្រើសអំពីការ​បង្ហាញស្លាយ';
$lang['More Information'] = 'ព័ត៌មាន​បន្ថែម';
$lang['Loop the slideshow'] = 'រង្វិលជុំស្លាយ';
$lang['Autohide the bar of the slideshow'] = 'លាក់របារស្លាយដោយស្វ័យប្រវត្តិ';
?>