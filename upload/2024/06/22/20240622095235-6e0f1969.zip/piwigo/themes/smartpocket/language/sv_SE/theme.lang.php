<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Dölj bildspelspanelen automatiskt';
$lang['Loop the slideshow'] = 'Loopa bildspelet';
$lang['More Information'] = 'Mer information';
$lang['Slideshow Options'] = 'Inställningar för bildspel';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, konfigurationssida';
?>