<?php
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Configuration Page';
$lang['Slideshow Options'] = 'Slideshow Options';
$lang['Loop the slideshow'] = 'Loop the slideshow';
$lang['Autohide the bar of the slideshow'] = 'Autohide the bar of the slideshow';
$lang['More Information'] = 'More Information';
?>