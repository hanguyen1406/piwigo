<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Nastavitve';
$lang['Slideshow Options'] = 'Nastavitve diaprojekcije';
$lang['More Information'] = 'Več informacij';
$lang['Loop the slideshow'] = 'Ponavljaj diaprojekcijo';
$lang['Autohide the bar of the slideshow'] = 'Samodejno skrij orodno vrstico diaprojekcije';
?>