<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Smartpocket, Configuration Page'] = 'ஸ்மார்ட் பாக்கெட்,கட்டமைப்பு பக்கம்';
$lang['Slideshow Options'] = 'படவில்லை விருப்பங்கள்';
$lang['More Information'] = 'மேலும் தகவலுக்கு';
$lang['Loop the slideshow'] = 'வளைய படவில்லை';
$lang['Autohide the bar of the slideshow'] = 'படவில்லை பட்டியில் தானாக மறை';
?>