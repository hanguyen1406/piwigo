<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Amaga automàticament la barra de la presentació de diapositives ';
$lang['Loop the slideshow'] = 'Repetir la presentació de diapositives ';
$lang['More Information'] = 'Més informació';
$lang['Slideshow Options'] = 'Opcions de la presentació de diapositives ';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Pàgina de configuració';
?>