<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Automatisk skjul linjen på lysbildefremvisningen';
$lang['Loop the slideshow'] = 'Repeter lysbildefremvisningen';
$lang['More Information'] = 'Mer informasjon';
$lang['Slideshow Options'] = 'Innstillinger på lysbildefremvisning';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, innstillinger';
?>