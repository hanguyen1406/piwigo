<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Aŭtomate kaŝi la breton dum bildoserio';
$lang['Loop the slideshow'] = 'Iteraci la bildoserion';
$lang['More Information'] = 'Pli da informo';
$lang['Slideshow Options'] = 'Bildoseriaj opcioj';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, agorda paĝo';
?>