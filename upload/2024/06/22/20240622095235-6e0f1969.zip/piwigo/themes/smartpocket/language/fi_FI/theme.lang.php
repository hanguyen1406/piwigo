<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Piilota palkki diaesityksestä automaattisesti';
$lang['Loop the slideshow'] = 'Toista diaesitys automaattisesti uudelleen';
$lang['More Information'] = 'Lisätietoja';
$lang['Slideshow Options'] = 'Diaesityksen valinnat';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, valintasivu';
?>