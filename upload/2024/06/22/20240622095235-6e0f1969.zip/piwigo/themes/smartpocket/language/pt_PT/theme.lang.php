<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Auto esconder a barra do slide show';
$lang['Loop the slideshow'] = 'Passar o slide show';
$lang['More Information'] = 'Mais informação';
$lang['Slideshow Options'] = 'Opções de slide show';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket - Página de configuração';
?>