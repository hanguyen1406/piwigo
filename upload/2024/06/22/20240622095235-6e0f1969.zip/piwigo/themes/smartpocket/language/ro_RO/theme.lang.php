<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Ascunde automat bara prezentarii';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, pagina de configurare';
$lang['Slideshow Options'] = 'Optiunile prezentarii';
$lang['More Information'] = 'Mai multe informatii';
$lang['Loop the slideshow'] = 'Reda prezentarea in bulca';
?>