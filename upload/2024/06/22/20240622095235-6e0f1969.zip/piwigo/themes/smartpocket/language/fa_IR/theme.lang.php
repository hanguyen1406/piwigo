<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Loop the slideshow'] = 'حلقه تصاویر به صورت خودکار';
$lang['Slideshow Options'] = 'گزینه نمایش به صورت اسلاید';
$lang['Autohide the bar of the slideshow'] = 'مخفی شونده خودکار نوار از تصاویر به صورت خودکار';
$lang['More Information'] = 'اطلاعات بیشتر';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket، پیکربندی صفحه';
?>