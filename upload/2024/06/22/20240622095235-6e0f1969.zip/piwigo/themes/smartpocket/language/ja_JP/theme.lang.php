<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'スライドショーのバーを自動で閉じるようにする';
$lang['Loop the slideshow'] = 'スライドショーをループさせる';
$lang['More Information'] = '詳細情報';
$lang['Slideshow Options'] = 'スライドショーオプション';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket 設定ページ';