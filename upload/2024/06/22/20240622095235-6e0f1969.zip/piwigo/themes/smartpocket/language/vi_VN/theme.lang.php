<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Tự động ẩn thanh công cụ khi trình chiếu';
$lang['Loop the slideshow'] = 'Lặp lại trình chiếu';
$lang['More Information'] = 'Thêm thông tin';
$lang['Slideshow Options'] = 'Các tùy chọn trình chiếu';
$lang['Smartpocket, Configuration Page'] = 'Ví thông minh, Trang cấu hình';
?>