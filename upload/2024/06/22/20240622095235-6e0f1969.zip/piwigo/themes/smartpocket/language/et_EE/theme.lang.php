<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Automaatselt peida slaidikava riba';
$lang['Loop the slideshow'] = 'Katkematu slaidikava';
$lang['More Information'] = 'Lisainfo';
$lang['Slideshow Options'] = 'Slaidikava valikud';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket\' seaded';
?>