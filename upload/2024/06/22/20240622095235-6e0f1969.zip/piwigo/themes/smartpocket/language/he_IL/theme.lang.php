<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'הסתר אוטומטית את פס התצוגה בהצגת תמונות ';
$lang['Loop the slideshow'] = 'הצג מצגת תמונות בלולאה';
$lang['More Information'] = 'מידע נוסף';
$lang['Slideshow Options'] = 'אפשרויות מצגת תמונות';
$lang['Smartpocket, Configuration Page'] = 'מכשיר חכם, עמוד הגדרות';
?>