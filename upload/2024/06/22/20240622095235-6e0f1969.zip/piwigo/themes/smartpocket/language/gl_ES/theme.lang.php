<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Auto-agochar a barra da presentación';
$lang['Loop the slideshow'] = 'Pase a presentación';
$lang['More Information'] = 'Máis información';
$lang['Slideshow Options'] = 'Opcións da presentación';
$lang['Smartpocket, Configuration Page'] = 'Dispositivo de peto, páxina de configuración';