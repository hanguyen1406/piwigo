<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Ocultar automáticamente la barra del pase de diapositivas';
$lang['Loop the slideshow'] = 'Pase de diapositivas en bucle';
$lang['More Information'] = 'Más información';
$lang['Slideshow Options'] = 'Opciones del pase de diapositivas';
$lang['Smartpocket, Configuration Page'] = 'Página de configuración de Smartpocket';