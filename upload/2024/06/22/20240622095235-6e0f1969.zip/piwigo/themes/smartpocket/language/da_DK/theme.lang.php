<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Autoskjul slideshowbjælken';
$lang['Loop the slideshow'] = 'Kør slideshowet i en løkke';
$lang['More Information'] = 'Flere oplysninger';
$lang['Slideshow Options'] = 'Slideshow-indstillinger';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, opsætningsside';
?>