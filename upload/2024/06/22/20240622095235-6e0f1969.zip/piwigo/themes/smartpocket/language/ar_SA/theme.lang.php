<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'الإخفاء التلقائي الشريط لعرض الشرائح';
$lang['Loop the slideshow'] = 'تكرار عرض شرائح';
$lang['More Information'] = 'مزيد من المعلومات';
$lang['Slideshow Options'] = 'خيارات عرض الشرائح';
$lang['Smartpocket, Configuration Page'] = 'آعدادت العرض الموبايل';