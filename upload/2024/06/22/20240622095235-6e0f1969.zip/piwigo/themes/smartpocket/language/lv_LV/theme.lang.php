<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Konfigurācijas lapa';
$lang['Autohide the bar of the slideshow'] = 'Automātiski paslēpt slaidrādes izvēlni';
$lang['Slideshow Options'] = 'Slaidrādes opcijas';
$lang['More Information'] = 'Vairāk informācijas';
$lang['Loop the slideshow'] = 'Ieciklēt slaidrādi';
?>