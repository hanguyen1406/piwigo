<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Διαμόρφωση σελίδας';
$lang['Slideshow Options'] = 'Επιλογές slideshow';
$lang['More Information'] = 'Περισσότερες πληροφορίες';
$lang['Loop the slideshow'] = 'Επανάληψη του slideshow';
$lang['Autohide the bar of the slideshow'] = 'Αυτόματη απόκρυψη της γραμμής του slideshow';
?>