<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Ocultar automáticamente la barra de la presentación de diapositivas';
$lang['Loop the slideshow'] = 'Poner en bucle la presentación de diapositivas';
$lang['More Information'] = 'Mas información';
$lang['Slideshow Options'] = 'Opciones de la presentación';
$lang['Smartpocket, Configuration Page'] = 'Pagina de configración para smartpocket';
?>