<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = 'Automatikoki ezkutatu diapositiba-aurkezpenaren barra';
$lang['Loop the slideshow'] = 'Errepikatu diapositiba-aurkezpena';
$lang['More Information'] = 'Informazio gehiago';
$lang['Slideshow Options'] = 'Diapositiba-aurkezpenaren aukerak';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, konfigurazio orria';