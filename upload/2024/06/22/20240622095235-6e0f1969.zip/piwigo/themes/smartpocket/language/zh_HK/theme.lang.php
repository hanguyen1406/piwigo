<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Autohide the bar of the slideshow'] = '自動隱藏幻燈片欄';
$lang['Loop the slideshow'] = '幻燈片循環播放';
$lang['More Information'] = '更多信息';
$lang['Slideshow Options'] = '幻燈片選項';
$lang['Smartpocket, Configuration Page'] = 'Smartpocket，配置頁';
?>