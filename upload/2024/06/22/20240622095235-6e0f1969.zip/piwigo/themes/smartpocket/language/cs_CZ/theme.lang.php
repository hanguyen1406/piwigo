<?php
$lang['Smartpocket, Configuration Page'] = 'Smartpocket, Stránka s nastavením';
$lang['Slideshow Options'] = 'Slideshow nastavení';
$lang['Loop the slideshow'] = 'Opakovat slideshow ve smyčce';
$lang['Autohide the bar of the slideshow'] = 'Automatické skrytí panelu ve slideshow';
$lang['More Information'] = 'Další Informace';
?>