<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['Smartpocket, Configuration Page'] = 'Pajenn gefluniañ Smartpocket';
$lang['Autohide the bar of the slideshow'] = 'Kuzhat barrenn an diaporama emgefreek';
$lang['Loop the slideshow'] = 'Adlañsañ dizehan an diaporama';
$lang['More Information'] = 'Muioc\'h a ditouroù';
$lang['Slideshow Options'] = 'Dibarzhioù an diaporama';
?>